var canvas;
var ctx;
var width;
var height;
var interval = 500;
position = {
   x: 200,
   y: 50,
}

function draw() {
   canvas = document.getElementById('canvas');
   width = canvas.width;
   height = canvas.height;
   ctx = canvas.getContext('2d');


   ctx.translate(-200, -300);

   setInterval(function () {
      ctx.clearRect(0, 0, 500, 500);
      drawGrass();
      drawHouse();
      drawSmoke();
   }, interval);

}


function drawSmoke() {
   for (count = 0; count <= 3; count++) {
      if (count = 0) {
         ctx.scale(1, 1);
         ctx.beginPath();
         ctx.arc(0, 0, 20, 0, 2 * Math.PI, false);
         ctx.fillStyle = 'yellow';
         ctx.fill();

      }
   }
   count = 0;
}

function changed(e) {

   interval = 1000 * (1 - e.value / 100);
   console.log(interval);
   clearInterval(intevalObject);
   intevalObject = setInterval(drawSmoke, interval);
   return;
}



function drawHouse() {
   var x = 200;
   var y = 200;
   ctx.translate(x, y);
   ctx.scale(0.8, 0.8);
   //wall
   ctx.beginPath();
   ctx.moveTo(-50, 100);
   ctx.lineTo(-50, 200);
   ctx.lineTo(125, 240);
   ctx.lineTo(125, 123);
   ctx.closePath();
   ctx.fillStyle = 'rgb(238,233,227)';
   ctx.fill();
   ctx.lineWidth = 1;
   ctx.strokeStyle = 'black';
   ctx.stroke();
   //wall2
   ctx.beginPath();
   ctx.moveTo(125, 123);
   ctx.lineTo(180, 20);
   ctx.lineTo(250, 90);
   ctx.lineTo(250, 200);
   ctx.lineTo(125, 240);
   ctx.closePath();
   ctx.fillStyle = 'rgb(185,182,177)';
   ctx.fill();
   ctx.lineWidth = 1;
   ctx.strokeStyle = 'black';
   ctx.stroke();
   // roof
   ctx.beginPath();
   ctx.moveTo(0, 0);
   ctx.lineTo(-60, 100);
   ctx.lineTo(120, 130);
   ctx.lineTo(180, 20);
   ctx.closePath();
   ctx.fillStyle = 'blue';
   ctx.fill();
   ctx.lineWidth = 1;
   ctx.strokeStyle = 'black';
   ctx.stroke();

   //roof2
   ctx.beginPath();
   ctx.moveTo(180, 20);
   ctx.lineTo(258, 98);
   ctx.lineTo(253, 98);
   ctx.lineTo(178, 24);
   ctx.closePath();
   ctx.fillStyle = 'rgb(17,83,131)';
   ctx.fill();
   ctx.lineWidth = 1;
   ctx.strokeStyle = 'black';
   ctx.stroke();

   //chimney
   ctx.beginPath();
   ctx.moveTo(20, 50);
   ctx.lineTo(20, -10);
   ctx.lineTo(35, -7);
   ctx.lineTo(35, 53);
   ctx.closePath();
   ctx.fillStyle = 'rgb(239,228,222)';
   ctx.fill();
   ctx.lineWidth = 1;
   ctx.strokeStyle = 'black';
   ctx.stroke();

   ctx.beginPath();
   ctx.moveTo(35, 53);
   ctx.lineTo(50, 35);
   ctx.lineTo(50, -10);
   ctx.lineTo(35, -7);
   ctx.closePath();
   ctx.fillStyle = 'rgb(222,199,192)';
   ctx.fill();
   ctx.lineWidth = 1;
   ctx.strokeStyle = 'black';
   ctx.stroke();

   ctx.beginPath();
   ctx.moveTo(20, -9);
   ctx.lineTo(35, -6);
   ctx.lineTo(50, -11);
   ctx.lineTo(32, -15);
   ctx.closePath();
   ctx.lineWidth = 3;
   ctx.strokeStyle = 'rgb(0,116,189)';
   ctx.stroke();

}

function drawGrass() {
   //grass
   var x = 0;
   var y = 0;
   ctx.translate(x, y);
   ctx.beginPath();
   ctx.moveTo(0, canvas.width / 1.5);
   ctx.lineTo(canvas.width, canvas.width / 1.5);
   ctx.lineTo(canvas.width, canvas.height);
   ctx.lineTo(0, canvas.height);
   ctx.closePath();
   ctx.fillStyle = 'rgb(11,195,72)';
   ctx.fill();
   

}
